const ROLES = {
  USER: "USER",
  ADMIN: "ADMIN"
};

module.exports = {
  ROLES,
}
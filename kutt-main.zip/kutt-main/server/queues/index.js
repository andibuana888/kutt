const { visit } = require("./queues");

module.exports = {
  visit,
};
